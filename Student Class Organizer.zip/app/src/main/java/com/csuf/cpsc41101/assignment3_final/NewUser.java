package com.csuf.cpsc41101.assignment3_final;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.Button;


public class NewUser extends SQLiteOpenHelper {


    //User Name Table
    private static final String DB_NAME = "Users.db";
    private static final String DB_TABLE = "Users_Table";
    //columns
    private static final String ID = "ID";
    private static final String NAME = "NAME";
    private static final String LASTNAME = "LASTNAME";
    private static final String CWID = "CWID";


    public NewUser(Context context){
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + DB_TABLE +" (ID INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT,LASTNAME TEXT,CWID INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ DB_TABLE);
        onCreate(db);
    }

    public boolean insertData(String name,String lastname,String cwid) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NAME,name);
        contentValues.put(LASTNAME,lastname);
        contentValues.put(CWID,cwid);
        long result = db.insert(DB_TABLE,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+ DB_TABLE,null);
        return res;
    }
}