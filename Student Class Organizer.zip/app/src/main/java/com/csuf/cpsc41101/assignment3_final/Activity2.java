package com.csuf.cpsc41101.assignment3_final;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Activity2 extends AppCompatActivity {

    NewUser db;
    Button add_button, add_class, button;
    EditText firstname, lastname, cwid;

    //declarations to add course id/grade

    private ArrayList<String> arrayList;
    private ArrayAdapter<String> adapter;
    private EditText txtInput;

    private ArrayList<String> arrayList1;
    private ArrayAdapter<String> adapter1;
    private EditText txtInput1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);


        //CourseID Add
        ListView courseIdView = (ListView)findViewById(R.id.courselist);
        String[] courselist = {};
        arrayList = new ArrayList<>(Arrays.asList(courselist));
        adapter = new ArrayAdapter<String>(this, R.layout.list_items, R.id.txtitem, arrayList);
        courseIdView.setAdapter(adapter);
        txtInput = (EditText)findViewById(R.id.courseListID);

        //Grade Add
        ListView courseIdView1 = (ListView)findViewById(R.id.gradelist);
        String[] courselist1 = {};
        arrayList1 = new ArrayList<>(Arrays.asList(courselist1));
        adapter1 = new ArrayAdapter<String>(this, R.layout.list_items, R.id.txtitem1, arrayList1);
        courseIdView1.setAdapter(adapter1);
        txtInput1 = (EditText)findViewById(R.id.gradeListID);



        db = new NewUser(this);

        add_button = (Button) findViewById(R.id.addcourse);
        firstname = (EditText) findViewById(R.id.firstname);
        lastname = (EditText) findViewById(R.id.lastname);
        cwid = (EditText) findViewById(R.id.CWID);

        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Activity2.this, "Course added!", Toast.LENGTH_LONG).show();

                String newItem = txtInput.getText().toString();
                arrayList.add(newItem);
                adapter.notifyDataSetChanged();

                String newItem1 = txtInput1.getText().toString();
                arrayList1.add(newItem1);
                adapter1.notifyDataSetChanged();

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menudone, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.item1:
                goMainActivity();
                boolean isInserted = db.insertData(firstname.getText().toString(), lastname.getText().toString(), cwid.getText().toString());
                if (isInserted == true)
                    Toast.makeText(Activity2.this, "Data added", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(Activity2.this, "Data not added", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
    public void goMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}




